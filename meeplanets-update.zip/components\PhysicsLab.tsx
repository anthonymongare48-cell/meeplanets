"use client";

import { useMemo, useState } from "react";
import { planets } from "@/lib/planets";
import { useCosmosStore } from "@/store/useCosmosStore";

export function PhysicsLab() {
  const selectedPlanetId = useCosmosStore((state) => state.selectedPlanet);
  const selectedPlanet = planets.find((planet) => planet.id === selectedPlanetId) ?? planets[2];
  const [angle, setAngle] = useState(42);
  const [speed, setSpeed] = useState(58);
  const [massScale, setMassScale] = useState(1);
  const [distance, setDistance] = useState(1);
  const [atmosphere, setAtmosphere] = useState(42);
  const [water, setWater] = useState(55);
  const [tilt, setTilt] = useState(23);
  const effectiveMass = selectedPlanet.massEarth * massScale;
  const assist = useMemo(() => Math.round((Math.sin(angle * Math.PI / 180) * speed * (1 + Math.log10(Math.max(.01, effectiveMass)) / 8))), [angle, speed, effectiveMass]);
  const habitability = useMemo(() => Math.max(0, Math.round(100 - Math.abs(distance - 1) * 38 - Math.abs(atmosphere - 42) * .55 - Math.abs(water - 55) * .32 - Math.abs(tilt - 23) * .6)), [distance, atmosphere, water, tilt]);
  return <div className="physics-grid"><section className="physics-card"><span className="eyebrow">SIMULATION 01 / ORBITAL MECHANICS</span><h2>{selectedPlanet.name} gravity slingshot</h2><p className="description">Tune a flyby of {selectedPlanet.name.toLowerCase()}. Mass uses the shared planet catalog; this toy model keeps the result legible, not predictive.</p><div className="slingshot-stage"><div className="gravity-well" style={{ background: selectedPlanet.accent, boxShadow: `0 0 55px ${selectedPlanet.accent}88` }} /><div className="trajectory" style={{ transform: `rotate(${angle - 45}deg) scaleX(${.65 + speed / 120})` }} /><div className="probe">◆</div></div><label>APPROACH ANGLE <output>{angle}°</output><input type="range" min="10" max="80" value={angle} onChange={(e) => setAngle(+e.target.value)} /></label><label>ARRIVAL SPEED <output>{speed} km/s</output><input type="range" min="20" max="100" value={speed} onChange={(e) => setSpeed(+e.target.value)} /></label><label>PLANET MASS SCALE <output>{effectiveMass.toLocaleString(undefined, { maximumFractionDigits: 1 })} M⊕</output><input type="range" min="0.2" max="8" step=".1" value={massScale} onChange={(e) => setMassScale(+e.target.value)} aria-label="Planet mass scale" /></label><div className="result-readout"><span>DEFLECTION INDEX</span><strong>{assist}</strong><small>{assist > 55 ? "Clean boost — exit velocity increased" : "Gentle pass — try a faster approach"}</small></div></section><section className="physics-card"><span className="eyebrow">SIMULATION 02 / PLANETARY CLIMATE</span><h2>Build an exoplanet</h2><p className="description">Explore how broad planetary ingredients change a fictional world’s first-pass habitability score.</p><div className="exoplanet-preview"><div className="exo-glow" style={{ opacity: .35 + water / 180 }} /><div className="exo" style={{ transform: `rotate(${tilt}deg)`, background: `linear-gradient(160deg, hsl(${190 + water}, 60%, 45%), #161b24 62%)` }} /></div><label>ORBITAL DISTANCE <output>{distance.toFixed(2)} AU</output><input type="range" min=".4" max="1.8" step=".01" value={distance} onChange={(e) => setDistance(+e.target.value)} /></label><label>ATMOSPHERE / N₂ + CO₂ <output>{atmosphere}%</output><input type="range" min="5" max="80" value={atmosphere} onChange={(e) => setAtmosphere(+e.target.value)} /></label><label>SURFACE WATER <output>{water}%</output><input type="range" min="0" max="100" value={water} onChange={(e) => setWater(+e.target.value)} /></label><label>AXIAL TILT <output>{tilt}°</output><input type="range" min="0" max="60" value={tilt} onChange={(e) => setTilt(+e.target.value)} /></label><div className="habitability"><span>FICTIONAL HABITABILITY INDEX</span><strong>{habitability}%</strong><small>{habitability > 70 ? "Temperate candidate" : habitability > 40 ? "Interesting, with constraints" : "Extreme conditions"}</small></div></section></div>;
}
